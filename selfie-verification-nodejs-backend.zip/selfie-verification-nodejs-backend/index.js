const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();
const { open } = require("sqlite");
const { v4: uuidv4 } = require("uuid");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

// Serve static files from the 'static' directory
app.use(express.static("static"));

let db;

// Initialize SQLite database
async function initializeDb() {
  db = await open({
    filename: "./database/app.db",
    driver: sqlite3.Database,
  });
  await db.exec(`
    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      transaction_id TEXT NOT NULL,
      liveness_id TEXT,
      status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
  console.log("Database initialized.");
}

// Mock API keys for demonstration
const VALID_API_KEYS = {
  "demo-api-key-123": "demo-device-001",
  "test-api-key-456": "test-device-002",
};

// Middleware to require API key
const requireApiKey = (req, res, next) => {
  const apiKey = req.headers["x-api-key"];
  const deviceId = req.headers["x-device-id"];

  if (!apiKey) {
    return res.status(401).json({ error: "API key missing in headers" });
  }

  if (!VALID_API_KEYS[apiKey]) {
    return res.status(401).json({ error: "Invalid API key" });
  }

  if (!deviceId) {
    return res.status(401).json({ error: "Device ID missing in headers" });
  }

  next();
};

// API Endpoints

// Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", service: "selfie-verification-backend" });
});

// Get Transaction
app.get("/api/v1/transaction", requireApiKey, async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.status(400).json({ error: "Query parameter q is required" });
  }

  let transaction = await db.get(
    "SELECT * FROM transactions WHERE user_id = ?",
    query
  );

  if (!transaction) {
    transaction = {
      id: uuidv4(),
      user_id: query,
      transaction_id: `txn_${uuidv4().slice(0, 8)}`,
      status: "pending",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    await db.run(
      "INSERT INTO transactions (id, user_id, transaction_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
      transaction.id,
      transaction.user_id,
      transaction.transaction_id,
      transaction.status,
      transaction.created_at,
      transaction.updated_at
    );
  }

  res.json(transaction);
});

// Update Transaction (PATCH)
app.patch("/api/v1/transaction", requireApiKey, async (req, res) => {
  const { liveness_id } = req.body;

  if (!liveness_id) {
    return res
      .status(400)
      .json({ error: "liveness_id is required in request body" });
  }

  let transaction = await db.get(
    "SELECT * FROM transactions WHERE liveness_id = ?",
    liveness_id
  );

  if (!transaction) {
    // If no transaction found by liveness_id, try to find a pending one
    transaction = await db.get("SELECT * FROM transactions WHERE status = ?", "pending");

    if (!transaction) {
      // Create a new transaction if no pending one exists
      transaction = {
        id: uuidv4(),
        user_id: `user_${uuidv4().slice(0, 8)}`,
        transaction_id: `txn_${uuidv4().slice(0, 8)}`,
        status: "pending",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      await db.run(
        "INSERT INTO transactions (id, user_id, transaction_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
        transaction.id,
        transaction.user_id,
        transaction.transaction_id,
        transaction.status,
        transaction.created_at,
        transaction.updated_at
      );
    }
  }

  // Update transaction
  const updated_at = new Date().toISOString();
  await db.run(
    "UPDATE transactions SET liveness_id = ?, status = ?, updated_at = ? WHERE id = ?",
    liveness_id,
    "completed",
    updated_at,
    transaction.id
  );

  const updatedTransaction = await db.get(
    "SELECT * FROM transactions WHERE id = ?",
    transaction.id
  );

  res.json({
    success: true,
    message: "Liveness ID updated successfully",
    transaction: updatedTransaction,
  });
});

// Get specific transaction by ID
app.get("/api/v1/transaction/:transaction_id", requireApiKey, async (req, res) => {
  const { transaction_id } = req.params;
  const transaction = await db.get(
    "SELECT * FROM transactions WHERE transaction_id = ?",
    transaction_id
  );

  if (!transaction) {
    return res.status(404).json({ error: "Transaction not found" });
  }

  res.json(transaction);
});

// List all transactions
app.get("/api/v1/transactions", requireApiKey, async (req, res) => {
  const transactions = await db.all("SELECT * FROM transactions ORDER BY created_at DESC");
  res.json(transactions);
});

// Start the server and initialize the database
initializeDb().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});


